//
//  ViewController.swift
//  OpenLibrary
//
//  Created by ratos on 12/03/16.
//  Copyright © 2016 diseñowebymas. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var nolibro: UITextField!
    @IBOutlet weak var txtResultado: UITextView!
    
    
    @IBAction func btnBuscar(sender: UIButton) {
        
        if ValidaConexion.isConnectedToNetwork() == true {
            
            if(nolibro.text != ""){
                
                txtResultado.text = ""
                
                let urlcadena = "https://openlibrary.org/api/books?jscmd=data&format=json&bibkeys=ISBN:" + nolibro.text!
                
                let urlfinal = NSURL(string: urlcadena)
                
                let datos: NSData? = NSData(contentsOfURL: urlfinal!)
                
                let texto = NSString(data: datos!, encoding: NSUTF8StringEncoding)
                txtResultado.text = texto as! String
                
            }else{
                txtResultado.text = "Escriba un texto de busqueda"
            }
            
        } else {
            
            txtResultado.text = "Sin Conexion a Internet. Verifique su conexion."
        }
        
        
    }
        

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        
    }


}

